[![BCH compliance](https://bettercodehub.com/edge/badge/hhs-semester-se-s2/Projectgroep-1b?branch=main&token=8849d6fe6b70459aab81c028c1c7e7ee3dbd40db)](https://bettercodehub.com/)
# opt2-javafx-fxml-navigatie
